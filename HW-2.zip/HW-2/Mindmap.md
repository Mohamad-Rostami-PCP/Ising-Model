# Project Name

## Importing Lib
- np : Numpy
- pd : Pandas
- plt : Matplotlib.pyplot



## Definig Variables

- Physical constants

- Numerical Constants

- Initial Conditions


- Global Variables
    
## Definig Functions
## Extracting Data
## Showing Data

## @Further Develops


